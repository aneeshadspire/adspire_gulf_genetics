# -*- coding: utf-8 -*-
from odoo import http

# class AdspireSimplifiedGenetics(http.Controller):
#     @http.route('/adspire_simplified_genetics/adspire_simplified_genetics/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/adspire_simplified_genetics/adspire_simplified_genetics/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('adspire_simplified_genetics.listing', {
#             'root': '/adspire_simplified_genetics/adspire_simplified_genetics',
#             'objects': http.request.env['adspire_simplified_genetics.adspire_simplified_genetics'].search([]),
#         })

#     @http.route('/adspire_simplified_genetics/adspire_simplified_genetics/objects/<model("adspire_simplified_genetics.adspire_simplified_genetics"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('adspire_simplified_genetics.object', {
#             'object': obj
#         })