# -*- coding: utf-8 -*-

import odoo.addons.decimal_precision as dp
from odoo import api, fields, models, _
from odoo.osv import osv


class res_partner_inherit(models.Model):
    _inherit = "res.partner"

    """ default value for SALE ASSOCIATE field as general associate"""         
    @api.model       
    def _get_default_sale_associate(self):
        associate_id = False
        associate_search = self.env['res.partner'].search([('name','=','General Associate')])
        if not associate_search:
            raise osv.except_osv(_('Error!'), _('Please choose General Associate for sales associate field. \n if you do not have a specific sale associate.'))
        else:
            associate_browse = self.env['res.partner'].browse(associate_search)[0]
            associate_id = associate_browse.id
        return associate_id

    associate = fields.Boolean(string='Is a Associate', default=True,
                               help="Check this box if this contact is a Associate.")
    sale_associate = fields.Many2one('res.partner', string='Sale Associates', required=False, default=_get_default_sale_associate)


class product_template_inherit(models.Model):

    _inherit = "product.template"

    commision_rate = fields.Float('Commision Rate %', required=True, digits=dp.get_precision('Product Price'), default=0.0)

class productproduct(models.Model):

    _inherit = "product.product"

    @api.model
    def create(self,vals):
        vals['website_published'] = True 
        res = super(productproduct, self).create(vals)
        return res

class saleorder_inherit(models.Model):

    _inherit = 'sale.order' 

    @api.one
    @api.depends('partner_id')
    def _compute_sale_associate(self):
        self.sale_associate = self.partner_id.sale_associate.id

    @api.depends('order_line')
    def get_commision_amt(self):
        comm_amt = 0.0
        if self.order_line:
            for each in self.order_line:
                comm_amt = each.commision_amt
        self.commision_amt = comm_amt

    @api.multi
    def _prepare_invoice(self):
        invoice_vals = super(saleorder_inherit, self)._prepare_invoice()
        invoice_vals.update({
            'sale_associate':self.sale_associate.id, 
            'commision_amt':self.commision_amt,
        })
        return invoice_vals

    @api.multi
    def action_sale_fast_confirm(self):
        """
        Confirms order and creates and validates invoice, confirms pickings.
        """
        for sale in self:
            # Process Order
            sale.action_confirm()
            inv_id = sale.action_invoice_create()
            if inv_id:
                inv = self.env['account.invoice'].browse(inv_id)
                print inv
                inv.action_invoice_open()
                res = sale.action_view_invoice()
            for picking in sale.picking_ids:
                picking.force_assign()
                picking.action_done()
            return res

    sale_associate = fields.Many2one('res.partner', string='Sale Associates', required=False,compute='_compute_sale_associate',store=True)
    commision_amt = fields.Float('Commision Amount', required=False, digits=dp.get_precision('Product Price'), default=0.0,compute='get_commision_amt',store=True)

class saleorder_line_inherit(models.Model):

    _inherit = 'sale.order.line'

    @api.one
    @api.depends('product_id','product_uom_qty','price_unit')
    def _compute_commision_amt(self):
        comm_rate = self.product_id.commision_rate
        profit_amt = self.price_unit - self.product_id.standard_price 
        # self.commision_amt = ((self.product_uom_qty * self.price_unit) * comm_rate)/100
        self.commision_amt = ((self.product_uom_qty * profit_amt) * comm_rate)/100

    commision_amt = fields.Float('Commision Amount', required=False, digits=dp.get_precision('Product Price'), default=0.0,compute='_compute_commision_amt',store=True)

class account_invoice_inherit(models.Model):

    _inherit = 'account.invoice'

    @api.one
    @api.depends('partner_id')
    def _compute_sale_associate(self):
        self.sale_associate = self.partner_id.sale_associate.id

    @api.depends('invoice_line_ids')
    def get_commision_amt(self):
        comm_amt = 0.0
        if self.invoice_line_ids:
            for each in self.invoice_line_ids:
                comm_amt = each.commision_amt
        self.commision_amt = comm_amt

    sale_associate = fields.Many2one('res.partner', string='Sale Associates', required=False,compute='_compute_sale_associate',store=True) 
    commision_amt = fields.Float('Commision Amount', required=False, digits=dp.get_precision('Product Price'), default=0.0,compute='get_commision_amt',store=True)

class saleorder_line_inherit(models.Model):

    _inherit = 'account.invoice.line'

    @api.one
    @api.depends('product_id','quantity','price_unit')
    def _compute_commision_amt(self):
        comm_rate = self.product_id.commision_rate
        profit_amt = self.price_unit - self.product_id.standard_price 
        # self.commision_amt = ((self.quantity * self.price_unit) * comm_rate)/100
        self.commision_amt = ((self.quantity * profit_amt) * comm_rate)/100

    commision_amt = fields.Float('Commision Amount', required=False, digits=dp.get_precision('Product Price'), default=0.0,compute='_compute_commision_amt',store=True)
